package com.TaskManagement.HomeAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
