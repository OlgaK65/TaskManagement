package com.TaskManagement.HomeAssignment.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.home_assignment.task_management.domain.AdvancedTask;
import com.home_assignment.task_management.domain.Task;

public interface TaskService {
	
	public Task returnResults(ResponseEntity<Task> responseEntity);
	public List<AdvancedTask> retrieveAll();
	public AdvancedTask putMark(String key, String mark);
	public AdvancedTask deleteTask(String key);
	public AdvancedTask getTask(String key);
	public AdvancedTask getTaskByRating();
	public ResponseEntity<Task> getActivity();
	public ResponseEntity<Task> getActivityByType(String type);
	public ResponseEntity<Task> getActivityByParticipants(String participants);
	public ResponseEntity<Task> getActivityByTypeAndParticipants(String type, String participants);
}
