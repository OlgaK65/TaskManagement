package com.TaskManagement.HomeAssignment.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AdvancedTask extends Task implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	TaskMark mark;
	Integer rating;
	
	
	public AdvancedTask(String activity, Float accessibility, String type, Integer participants, Float price, String key) {
		super(activity, accessibility, type, participants, price, key);
		rating = 0;
	}

	public AdvancedTask(String activity, Float accessibility, String type, Integer participants, Float price) {
		super(activity, accessibility, type, participants, price);
		rating = 0;
	}

	public AdvancedTask(Task task) {
		super(task);
		rating = 0;
	}
}
