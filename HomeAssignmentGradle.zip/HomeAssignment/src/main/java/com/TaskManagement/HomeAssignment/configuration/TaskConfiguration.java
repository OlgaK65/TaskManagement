package com.TaskManagement.HomeAssignment.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.home_assignment.task_management.domain.AdvancedTask;

@Configuration
public class TaskConfiguration {
	@Bean
	public Map<String,AdvancedTask> taskMap(){
		return new HashMap<String, AdvancedTask>();
	}
}