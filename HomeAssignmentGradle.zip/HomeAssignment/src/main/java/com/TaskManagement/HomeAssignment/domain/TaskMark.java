package com.TaskManagement.HomeAssignment.domain;

public enum TaskMark {
	WISH_LIST,
	COMPLETED
}
