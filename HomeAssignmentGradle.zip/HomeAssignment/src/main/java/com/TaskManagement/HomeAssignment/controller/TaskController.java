package com.TaskManagement.HomeAssignment.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.home_assignment.task_management.domain.AdvancedTask;
import com.home_assignment.task_management.domain.Task;
import com.home_assignment.task_management.domain.TaskMark;
import com.home_assignment.task_management.service.TaskService;

@RestController
public class TaskController {
	
	@Autowired
	TaskService taskService;
	
	@GetMapping("/task_of_the_day")
	public Task retrieveTaskOfTheDay(){			
		ResponseEntity<Task> responseEntity = taskService.getActivity();			
		return taskService.returnResults(responseEntity);
	}
		
	@GetMapping("/get_type")
	public Task retrieveTaskType(@RequestParam String type){
		ResponseEntity<Task> responseEntity = taskService.getActivityByType(type);
		return taskService.returnResults(responseEntity);
	}
	
	@GetMapping("/get_participants")
	public Task retrieveTaskParticipants(@RequestParam String participants){		
		ResponseEntity<Task> responseEntity = taskService.getActivityByParticipants(participants);
		return taskService.returnResults(responseEntity);
	}
	
	@GetMapping("/get_type_and_participants")
	public Task retrieveTaskTypeAndParticipants(@RequestParam String type, @RequestParam String participants){
		ResponseEntity<Task> responseEntity = taskService.getActivityByTypeAndParticipants(type, participants);	
		return taskService.returnResults(responseEntity);
	}
	
	@GetMapping("/get_all_tasks")
	public List<AdvancedTask> retrieveAll(){
		return taskService.retrieveAll();		
	}
	
	@GetMapping("/get_wish_tasks")
	public List<AdvancedTask> retrieveWishList(){
		return taskService.retrieveAll().stream()
				.filter(t -> t.getMark() == TaskMark.WISH_LIST)
				.collect(Collectors.toList());		
	}
	
	@GetMapping("/get_completed_tasks")
	public List<AdvancedTask> retrieveCompleted(){
		return taskService.retrieveAll().stream()
				.filter(t -> t.getMark() == TaskMark.COMPLETED)
				.collect(Collectors.toList());		
	}
	
	@PutMapping("/task_mark")
	public AdvancedTask putTaskMark(@RequestParam String key, @RequestParam String mark) {
		Boolean wish = mark.equals("w");
		Boolean complete = mark.equals("c");
		
		if(!wish && !complete)
		  return null;
		
		return taskService.putMark(key, mark);
	}
	
	@DeleteMapping("/task_delete")
	public AdvancedTask deleteTask(@RequestParam String key) {
		return taskService.deleteTask(key);
	}
	
	@GetMapping("/task_get")
	public AdvancedTask getTask(@RequestParam String key) {
		return taskService.getTask(key);
	}
	
	@GetMapping("/task_by_rating")
	public AdvancedTask getTaskByRating() {
		return taskService.getTaskByRating();		
	}
}

