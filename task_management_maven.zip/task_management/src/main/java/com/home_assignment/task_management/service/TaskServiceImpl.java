package com.home_assignment.task_management.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.home_assignment.task_management.domain.AdvancedTask;
import com.home_assignment.task_management.domain.Task;
import com.home_assignment.task_management.domain.TaskMark;

@Service
public class TaskServiceImpl implements TaskService {

	@Autowired
	private Map<String, AdvancedTask> taskMap;
	
	public Task returnResults(ResponseEntity<Task> responseEntity) {
		if(responseEntity.getStatusCode() == HttpStatus.OK) {
			Task task = responseEntity.getBody();
			taskMap.put(task.getKey(), new AdvancedTask(task));
			return task;			
		}	
		else
			return null;
	}
	
	public List<AdvancedTask> retrieveAll() {
		return taskMap.values().stream().collect(Collectors.toList());
	}

	public AdvancedTask putMark(String key, String mark) {
		
		AdvancedTask aTask = taskMap.get(key);
		if(aTask != null){
			if(mark.equals("w")) {
				aTask.setMark(TaskMark.WISH_LIST);
				aTask.setRating(aTask.getRating()+1);
			}
			if(mark.equals("c")) {
				aTask.setMark(TaskMark.COMPLETED);
				aTask.setRating(aTask.getRating()+2);
			}	
		}
		
		return aTask;		
	}
	
	public AdvancedTask deleteTask(String key) {	
		return taskMap.remove(key);
	}
	
	public AdvancedTask getTask(String key) {
		 return taskMap.get(key);
	}

	public AdvancedTask getTaskByRating() {
	
		if(taskMap.size() == 0)
			return null;
		
		List<Integer> ratings = getRatings(); 
		List<AdvancedTask> rateList;
		Random rand = new Random();
		int prob = rand.nextInt(100)+1;
		Integer rating = getRating(prob, ratings);
		
		Predicate<AdvancedTask> pred1 = t -> t.getRating() == rating;
		Predicate<AdvancedTask> pred2 = t -> t.getRating() < rating;
		Predicate<AdvancedTask> pred;	 
		
		if(prob <= 60) // rating 20+20+10+5+5
			pred = pred1;
		else
			pred = pred2;
		
		if(rating > 0) {		
				rateList = taskMap.values().stream()
			            .filter(pred)
			            .collect(Collectors.toList());			
		}	
		else
			rateList = taskMap.values().stream()
					.collect(Collectors.toList());
		
	    if(rateList.size() == 0)
	    	return null;
	    else
		    return rateList.get(rand.nextInt(rateList.size()));   
		
	}
	
	private List<Integer> getRatings(){  // ratings sorted desc
		List<Integer> ratings = taskMap.values().stream()			
                .map(tl -> tl.getRating())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
		Collections.reverse(ratings);
		return ratings;
	}
	
	private Integer getRating(int prob, List<Integer> ratings) { // get rating by probability
		int len = ratings.size();
		if(len == 0 )
			return 0;  
		
		int percents[] = { 20, 20, 10, 5, 5, 40 }, sum = 0; 
		
		for(int i = 0; i < 6; i++) {
		  sum+=	percents[i];
		  if(prob <= sum || len <= i+1)
			  return ratings.get(i);
		}
		
		return 0;
	}	
	
	public ResponseEntity<Task> getActivity(){
		RestTemplate template = new RestTemplate();
		ResponseEntity<Task> responseEntity = template
			.getForEntity( "https://www.boredapi.com/api/activity", Task.class);	
		return responseEntity;
	}	
	
	public ResponseEntity<Task> getActivityByType(String type){
		HashMap<String, String> uriVariables = new HashMap<String, String>();	
		uriVariables.put("type", type);
		RestTemplate template = new RestTemplate();
		ResponseEntity<Task> responseEntity = template
		.getForEntity( "https://www.boredapi.com/api/activity?type={type}", Task.class,uriVariables);
		return responseEntity;
	}	
	
	public ResponseEntity<Task> getActivityByParticipants(String participants){
		HashMap<String,String> uriVariables = new HashMap<String, String>();	
		uriVariables.put("participants", participants);
		RestTemplate template = new RestTemplate();
		ResponseEntity<Task> responseEntity = template
		.getForEntity( "https://www.boredapi.com/api/activity?participants={participants}", Task.class,uriVariables);
		return responseEntity;
	}	
	
	public ResponseEntity<Task> getActivityByTypeAndParticipants(String type, String participants){
		HashMap<String, String> uriVariables = new HashMap<String, String>();	
		uriVariables.put("type", type);
		uriVariables.put("participants", participants);
		RestTemplate template = new RestTemplate();
		ResponseEntity<Task> responseEntity = template
		.getForEntity( "https://www.boredapi.com/api/activity?type={type}&participants={participants}", Task.class,uriVariables);
		return responseEntity;
	}	
}
