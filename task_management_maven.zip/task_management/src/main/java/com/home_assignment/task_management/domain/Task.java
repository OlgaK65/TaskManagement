package com.home_assignment.task_management.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Task implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String activity;	
	private Float accessibility;
	private String type;
	private Integer participants;
	private Float price;
	private String link;
	private String key;
	
	public Task() {};
	
//	{"activity":"Write a handwritten letter to somebody","type":"social","participants":1,"price":0.1,"link":"","key":"2277801","accessibility":0.8}
	public Task(String activity,
			     Float accessibility,
			     String type,
			     Integer participants,
			     Float price,
			     String link,
			     String key
			) {
		this.activity = activity;
		this.accessibility = accessibility;
		this.type = type;
		this.participants = participants;
		this.price = price;
		this.link = link;
		this.key = key;
	}
	
	
	public Task(String activity,	
					Float accessibility,
					String type,
					Integer participants,
	                Float price, 
	                String key) {
		this.activity = activity;
		this.accessibility = accessibility;
		this.type = type;		
		this.participants = participants;
		this.price = price;
		this.key = key;
	}
	
	
	public Task(String activity,	
					Float accessibility,
					String type,
					Integer participants,
					Float price) {
		this.activity = activity;
		this.accessibility = accessibility;
		this.type = type;		
		this.participants = participants;
		this.price = price;
	}
	
	public Task(Task task) {
		this.activity = task.activity;
		this.accessibility = task.accessibility;
		this.type = task.type;		
		this.participants = task.participants;
		this.price = task.price;
		this.key = task.key;
	}
}
