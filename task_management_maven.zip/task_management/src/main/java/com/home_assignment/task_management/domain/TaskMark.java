package com.home_assignment.task_management.domain;

public enum TaskMark {
	WISH_LIST,
	COMPLETED
}
